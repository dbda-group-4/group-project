import sys
import pymysql

rds_host  = "Endpoint of RDS"
name = "Master Username"
password = "Master Password"
db_name = "Database Name"
def save_events(event):
	conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
	cursor = conn.cursor()
        cursor.execute("use <databse name>")
        cursor.execute("DROP TABLE IF EXISTS <Table Name>")
	sql = """CREATE TABLE <Table Name> (FIRST_NAME  CHAR(20) NOT NULL, LAST_NAME  CHAR(20), AGE INT, SEX CHAR(1), INCOME FLOAT )"""
	cursor.execute(sql)
	conn.commit()
	
def lambda_handler(event, context):
	save_events(event)
